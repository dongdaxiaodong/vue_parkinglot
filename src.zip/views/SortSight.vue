<template>
   <div>
       fffwwss
   </div>
</template>
<script>

// import sortSightCom from "@/components/sortSightCom.vue"
export default {
    name:"SortSight"
}
</script>
